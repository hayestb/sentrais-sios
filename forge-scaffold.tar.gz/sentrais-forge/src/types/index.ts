export type Entity = "SentraisCorp" | "SRI" | "BGI" | "Ventures" | "ARI";
export type NINPhase = "D1" | "D2" | "D3" | "D4" | "D5";
export type GateStage = `G${0|1|2|3|4|5|6}` | `AV-G${0|1|2|3|4|5|6}` | `NC-G${0|1|2|3|4|5|6}`;
export type DoctrineMode = "SteadyState" | "Surge" | "IROPS" | "SecurityIncident" | "Recovery" | "ActiveThreat" | "SuperCycleWatch";
export type RevenueType = "TrainingFee" | "LicenseRoyalty" | "SingleEvent" | "AnnualSubscription" | "Grant" | "FederalContract" | "PPP";

export interface EvidenceLedgerEntry {
  id: string;
  hash: string;
  timestamp: string;
  actor: string;
  entityType: "engagement" | "gate" | "decision" | "milestone" | "invoice" | "claim";
  entityId: string;
  summary: string;
  previousHash: string;
}

export interface Engagement {
  id: string;
  name: string;
  entity: Entity;
  ninPhase: NINPhase;
  gateStage: GateStage;
  doctrineMode: DoctrineMode;
  revenueType: RevenueType;
  hardBlockFlag: boolean;
  claimsConfirmed: boolean;
  mondayBoardId?: string;
  hubspotDealId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface GateRecord {
  id: string;
  engagementId: string;
  stage: GateStage;
  passedAt?: string;
  blockedAt?: string;
  blockReason?: string;
  evidenceHash: string;
}

export interface Invoice {
  id: string;
  engagementId: string;
  entity: Entity;
  amount: number;
  revenueType: RevenueType;
  subcontractorEntity?: "SEG" | "None";
  subcontractorShare?: number;
  netSentraisAmount?: number;
  dueDate: string;
  status: "Draft" | "Sent" | "Paid" | "Overdue";
  nflMsaRef?: string;
  evidenceHash: string;
  createdAt: string;
}

export interface RevenueAllocation {
  entity: Entity;
  grossRevenue: number;
  subcontractorPayable: number;
  netRevenue: number;
  intercompanyTransfer: number;
  grantAmount: number;
  period: string;
}

export interface SEGSubcontract {
  dealId: string;
  dealName: string;
  gdaloliveDate?: string;
  subcontractStatus: "NA" | "TermSheetDrafting" | "TermSheetSigned" | "AgreementDrafting" | "AgreementExecuted" | "Active" | "Terminated";
  revenueSharePct: number;
  nflMsaRef?: string;
  warningFlag: boolean;
}

export interface ARIEngagement {
  id: string;
  programName: string;
  city: string;
  partneredEntity: Entity;
  status: "Pipeline" | "Active" | "Complete";
  campusGridActive: boolean;
  mouSigned: boolean;
  federalResearchPipeline: boolean;
  createdAt: string;
}
