import React from "react";
import { NavLink } from "react-router-dom";
import { cn } from "../../lib/utils";
import {
  LayoutDashboard, Briefcase, Shield, DollarSign, FileText,
  BookOpen, Building2, Activity, LogOut, Zap
} from "lucide-react";
import { auth } from "../../lib/firebase";
import { signOut } from "firebase/auth";

const nav = [
  { label: "Command Center", to: "/", icon: LayoutDashboard },
  { label: "Engagements", to: "/engagements", icon: Briefcase },
  { label: "Gate Tracker", to: "/gates", icon: Shield },
  { label: "Financial Ops", to: "/finance", icon: DollarSign },
  { label: "Evidence Ledger", to: "/evidence", icon: FileText },
  { label: "Claims Register", to: "/claims", icon: BookOpen },
  { label: "ARI Programs", to: "/ari", icon: Building2 },
  { label: "SEG Subcontract", to: "/seg", icon: Activity },
  { label: "FORGE Agents", to: "/agents", icon: Zap },
];

export function Sidebar() {
  return (
    <aside className="w-56 min-h-screen flex flex-col" style={{ background: "var(--forge-navy-mid)", borderRight: "1px solid var(--forge-border)" }}>
      <div className="px-5 py-6">
        <div className="text-xs font-bold tracking-widest uppercase mb-1" style={{ color: "var(--forge-gold)" }}>FORGE</div>
        <div className="text-xs" style={{ color: "var(--forge-text-dim)" }}>Command Center</div>
      </div>

      <nav className="flex-1 px-3 space-y-0.5">
        {nav.map(({ label, to, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 px-3 py-2 rounded text-sm transition-colors",
                isActive
                  ? "text-white font-medium"
                  : "hover:text-white"
              )
            }
            style={({ isActive }) => ({
              background: isActive ? "var(--forge-navy-light)" : undefined,
              color: isActive ? "var(--forge-text)" : "var(--forge-text-dim)",
            })}
          >
            <Icon size={15} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="px-3 py-4 border-t" style={{ borderColor: "var(--forge-border)" }}>
        <button
          onClick={() => signOut(auth)}
          className="flex items-center gap-3 px-3 py-2 rounded text-sm w-full transition-colors hover:text-white"
          style={{ color: "var(--forge-text-dim)" }}
        >
          <LogOut size={15} />
          Sign out
        </button>
      </div>
    </aside>
  );
}
