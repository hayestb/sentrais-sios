import React from "react";
import { cn } from "../../lib/utils";

type Variant = "default" | "gold" | "green" | "red" | "dim";

const variants: Record<Variant, React.CSSProperties> = {
  default: { background: "var(--forge-navy-light)", color: "var(--forge-accent)" },
  gold: { background: "#2a1f00", color: "var(--forge-gold)" },
  green: { background: "#0a2010", color: "#4ade80" },
  red: { background: "#200a0a", color: "#f87171" },
  dim: { background: "var(--forge-navy-mid)", color: "var(--forge-text-dim)" },
};

interface BadgeProps {
  children: React.ReactNode;
  variant?: Variant;
  className?: string;
}

export function Badge({ children, variant = "default", className }: BadgeProps) {
  return (
    <span
      className={cn("inline-flex items-center px-2 py-0.5 rounded text-xs font-medium", className)}
      style={variants[variant]}
    >
      {children}
    </span>
  );
}
