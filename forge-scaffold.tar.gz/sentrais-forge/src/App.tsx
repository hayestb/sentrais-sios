import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./hooks/useAuth";
import { AppShell } from "./components/layout/AppShell";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { FinancialOps } from "./pages/FinancialOps";
import { ARIPrograms } from "./pages/ARIPrograms";
import { EvidenceLedger } from "./pages/EvidenceLedger";

function ProtectedRoutes() {
  const { user, loading } = useAuth();
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--forge-navy)" }}>
      <div className="text-sm" style={{ color: "var(--forge-text-dim)" }}>Loading...</div>
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  return <AppShell />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route element={<ProtectedRoutes />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/finance" element={<FinancialOps />} />
          <Route path="/ari" element={<ARIPrograms />} />
          <Route path="/evidence" element={<EvidenceLedger />} />
          <Route path="/engagements" element={<ComingSoon title="Engagements" />} />
          <Route path="/gates" element={<ComingSoon title="Gate Tracker" />} />
          <Route path="/claims" element={<ComingSoon title="Claims Register" />} />
          <Route path="/seg" element={<Navigate to="/finance" replace />} />
          <Route path="/agents" element={<ComingSoon title="FORGE Agents" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

function ComingSoon({ title }: { title: string }) {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold mb-2" style={{ color: "var(--forge-text)" }}>{title}</h1>
      <p className="text-sm" style={{ color: "var(--forge-text-dim)" }}>This module is under construction.</p>
    </div>
  );
}
