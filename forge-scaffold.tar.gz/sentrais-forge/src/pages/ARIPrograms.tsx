import React, { useState } from "react";
import { Card, CardHeader, CardTitle } from "../components/ui/Card";
import { Badge } from "../components/ui/Badge";
import type { ARIEngagement } from "../types";

const ARI_PROGRAMS: ARIEngagement[] = [
  {
    id: "ARI-001",
    programName: "Atlanta CampusGrid — HBCU Cohort",
    city: "Atlanta, GA",
    partneredEntity: "BGI",
    status: "Active",
    campusGridActive: true,
    mouSigned: true,
    federalResearchPipeline: false,
    createdAt: "2026-01-15",
  },
  {
    id: "ARI-002",
    programName: "SEAR 2026 — Atlanta Node (ARI Co-Delivery)",
    city: "Atlanta, GA",
    partneredEntity: "SentraisCorp",
    status: "Active",
    campusGridActive: false,
    mouSigned: true,
    federalResearchPipeline: true,
    createdAt: "2026-02-01",
  },
  {
    id: "ARI-003",
    programName: "Federal Research Pipeline — FEMA/DHS Engagement",
    city: "Atlanta, GA",
    partneredEntity: "BGI",
    status: "Pipeline",
    campusGridActive: false,
    mouSigned: false,
    federalResearchPipeline: true,
    createdAt: "2026-05-20",
  },
];

export function ARIPrograms() {
  const [selected, setSelected] = useState<ARIEngagement | null>(null);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: "var(--forge-text)" }}>Atlanta Resilient Institute</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--forge-text-dim)" }}>
          ARI program engagements — partnered via BGI and Sentrais Corp delivery
        </p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card>
          <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>Active Programs</div>
          <div className="text-2xl font-bold" style={{ color: "#4ade80" }}>
            {ARI_PROGRAMS.filter((p) => p.status === "Active").length}
          </div>
        </Card>
        <Card>
          <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>MOUs Signed</div>
          <div className="text-2xl font-bold" style={{ color: "var(--forge-accent)" }}>
            {ARI_PROGRAMS.filter((p) => p.mouSigned).length}
          </div>
        </Card>
        <Card>
          <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>Federal Pipeline</div>
          <div className="text-2xl font-bold" style={{ color: "var(--forge-gold)" }}>
            {ARI_PROGRAMS.filter((p) => p.federalResearchPipeline).length}
          </div>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>ARI Programs</CardTitle></CardHeader>
        <div className="space-y-0">
          {ARI_PROGRAMS.map((p) => (
            <div
              key={p.id}
              className="py-3 border-b last:border-0 cursor-pointer hover:bg-opacity-50 transition-colors"
              style={{ borderColor: "var(--forge-border)" }}
              onClick={() => setSelected(selected?.id === p.id ? null : p)}
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-sm font-medium" style={{ color: "var(--forge-text)" }}>{p.programName}</div>
                  <div className="text-xs mt-0.5" style={{ color: "var(--forge-text-dim)" }}>
                    {p.city} · Partnered: {p.partneredEntity}
                  </div>
                </div>
                <Badge variant={p.status === "Active" ? "green" : p.status === "Complete" ? "dim" : "gold"}>
                  {p.status}
                </Badge>
              </div>

              {selected?.id === p.id && (
                <div className="mt-3 grid grid-cols-3 gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span style={{ color: p.mouSigned ? "#4ade80" : "#f87171" }}>●</span>
                    <span style={{ color: "var(--forge-text-dim)" }}>MOU {p.mouSigned ? "signed" : "pending"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span style={{ color: p.campusGridActive ? "#4ade80" : "var(--forge-text-dim)" }}>●</span>
                    <span style={{ color: "var(--forge-text-dim)" }}>CampusGrid {p.campusGridActive ? "active" : "not active"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span style={{ color: p.federalResearchPipeline ? "var(--forge-gold)" : "var(--forge-text-dim)" }}>●</span>
                    <span style={{ color: "var(--forge-text-dim)" }}>Federal pipeline {p.federalResearchPipeline ? "active" : "inactive"}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <CardHeader><CardTitle>ARI Operating Notes</CardTitle></CardHeader>
        <div className="text-sm space-y-2" style={{ color: "var(--forge-text-dim)" }}>
          <p>ARI operates as a research and community resilience partner to BGI and Sentrais Corp. All commercial delivery is routed through Sentrais Corp (prime). ARI engagements involving federal funding route through BGI research pipeline.</p>
          <p>CampusGrid engagements (Module D) require signed MOU and Clery/NIMS compliance validation before UN-G2 gate passage.</p>
          <p style={{ color: "#f87171" }}><strong style={{ color: "var(--forge-text)" }}>Inurement guard:</strong> ARI grant income must not flow to Sentrais Corp or SRI. Contact BGI legal before structuring any revenue-sharing agreement involving ARI.</p>
        </div>
      </Card>
    </div>
  );
}
