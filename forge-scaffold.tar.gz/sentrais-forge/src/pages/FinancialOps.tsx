import React, { useState } from "react";
import { Card, CardHeader, CardTitle } from "../components/ui/Card";
import { Badge } from "../components/ui/Badge";
import { formatCurrency, formatDate } from "../lib/utils";
import type { RevenueAllocation, SEGSubcontract, Invoice } from "../types";

const ALLOCATIONS: RevenueAllocation[] = [
  { entity: "SentraisCorp", grossRevenue: 1200000, subcontractorPayable: 840000, netRevenue: 360000, intercompanyTransfer: 80000, grantAmount: 0, period: "Q2 2026" },
  { entity: "SRI", grossRevenue: 80000, subcontractorPayable: 0, netRevenue: 80000, intercompanyTransfer: 80000, grantAmount: 0, period: "Q2 2026" },
  { entity: "BGI", grossRevenue: 85000, subcontractorPayable: 0, netRevenue: 85000, intercompanyTransfer: 0, grantAmount: 60000, period: "Q2 2026" },
  { entity: "ARI", grossRevenue: 40000, subcontractorPayable: 0, netRevenue: 40000, intercompanyTransfer: 0, grantAmount: 40000, period: "Q2 2026" },
  { entity: "Ventures", grossRevenue: 0, subcontractorPayable: 0, netRevenue: 0, intercompanyTransfer: 0, grantAmount: 0, period: "Q2 2026" },
];

const SEG_CONTRACTS: SEGSubcontract[] = [
  {
    dealId: "NFL-GDA-001",
    dealName: "NFL GDA — Sentrais Prime",
    gdaloliveDate: "2026-09-01",
    subcontractStatus: "TermSheetSigned",
    revenueSharePct: 70,
    nflMsaRef: "NFL-MSA-2026-001",
    warningFlag: true,
  },
];

const INVOICES: Invoice[] = [
  {
    id: "INV-2026-001",
    engagementId: "NFL-GDA-001",
    entity: "SentraisCorp",
    amount: 400000,
    revenueType: "FederalContract",
    subcontractorEntity: "SEG",
    subcontractorShare: 280000,
    netSentraisAmount: 120000,
    dueDate: "2026-07-01",
    status: "Draft",
    nflMsaRef: "NFL-MSA-2026-001",
    evidenceHash: "",
    createdAt: "2026-06-08",
  },
];

const entityColor: Record<string, string> = {
  SentraisCorp: "var(--forge-accent)",
  SRI: "#a78bfa",
  BGI: "#34d399",
  ARI: "#f59e0b",
  Ventures: "#60a5fa",
};

type Tab = "allocation" | "seg" | "invoices";

export function FinancialOps() {
  const [tab, setTab] = useState<Tab>("allocation");

  const totalGross = ALLOCATIONS.reduce((s, a) => s + a.grossRevenue, 0);
  const totalNet = ALLOCATIONS.reduce((s, a) => s + a.netRevenue, 0);
  const totalSubcontractor = ALLOCATIONS.reduce((s, a) => s + a.subcontractorPayable, 0);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: "var(--forge-text)" }}>Financial Operations</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--forge-text-dim)" }}>
          Multi-entity revenue allocation · SEG subcontract tracking · Invoicing
        </p>
      </div>

      {/* Summary strip */}
      <div className="grid grid-cols-3 gap-4">
        <Card>
          <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>Total Pipeline (Q2 2026)</div>
          <div className="text-2xl font-bold" style={{ color: "var(--forge-text)" }}>{formatCurrency(totalGross)}</div>
        </Card>
        <Card>
          <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>Net to Sentrais entities</div>
          <div className="text-2xl font-bold" style={{ color: "#4ade80" }}>{formatCurrency(totalNet)}</div>
        </Card>
        <Card>
          <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>SEG payable (70% rev share)</div>
          <div className="text-2xl font-bold" style={{ color: "var(--forge-gold)" }}>{formatCurrency(totalSubcontractor)}</div>
          {SEG_CONTRACTS[0].warningFlag && (
            <Badge variant="red" className="mt-2">Agreement not executed</Badge>
          )}
        </Card>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b" style={{ borderColor: "var(--forge-border)" }}>
        {(["allocation", "seg", "invoices"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="px-4 py-2 text-sm capitalize transition-colors"
            style={{
              color: tab === t ? "var(--forge-text)" : "var(--forge-text-dim)",
              borderBottom: tab === t ? "2px solid var(--forge-accent)" : "2px solid transparent",
            }}
          >
            {t === "seg" ? "SEG Subcontract" : t === "allocation" ? "Revenue Allocation" : "Invoices"}
          </button>
        ))}
      </div>

      {tab === "allocation" && (
        <Card>
          <CardHeader><CardTitle>Entity Revenue Allocation — {ALLOCATIONS[0].period}</CardTitle></CardHeader>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs border-b" style={{ color: "var(--forge-text-dim)", borderColor: "var(--forge-border)" }}>
                <th className="text-left py-2">Entity</th>
                <th className="text-right py-2">Gross Revenue</th>
                <th className="text-right py-2">Subcontractor Payable</th>
                <th className="text-right py-2">Intercompany Transfer</th>
                <th className="text-right py-2">Grant Income</th>
                <th className="text-right py-2">Net Revenue</th>
              </tr>
            </thead>
            <tbody>
              {ALLOCATIONS.map((a) => (
                <tr key={a.entity} className="border-b" style={{ borderColor: "var(--forge-border)" }}>
                  <td className="py-2.5 font-medium" style={{ color: entityColor[a.entity] }}>{a.entity}</td>
                  <td className="text-right py-2.5" style={{ color: "var(--forge-text)" }}>{formatCurrency(a.grossRevenue)}</td>
                  <td className="text-right py-2.5" style={{ color: a.subcontractorPayable > 0 ? "var(--forge-gold)" : "var(--forge-text-dim)" }}>
                    {a.subcontractorPayable > 0 ? `(${formatCurrency(a.subcontractorPayable)})` : "—"}
                  </td>
                  <td className="text-right py-2.5" style={{ color: "var(--forge-text-dim)" }}>
                    {a.intercompanyTransfer > 0 ? formatCurrency(a.intercompanyTransfer) : "—"}
                  </td>
                  <td className="text-right py-2.5" style={{ color: a.grantAmount > 0 ? "#34d399" : "var(--forge-text-dim)" }}>
                    {a.grantAmount > 0 ? formatCurrency(a.grantAmount) : "—"}
                  </td>
                  <td className="text-right py-2.5 font-semibold" style={{ color: "#4ade80" }}>{formatCurrency(a.netRevenue)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-3 text-xs p-3 rounded" style={{ background: "var(--forge-navy-mid)", color: "var(--forge-text-dim)" }}>
            <strong style={{ color: "var(--forge-text)" }}>Inurement Guard (BGI/ARI):</strong> Grant income must not flow to commercial entities.
            BGI and ARI net revenue is restricted to research and program delivery only.
          </div>
        </Card>
      )}

      {tab === "seg" && (
        <div className="space-y-4">
          {SEG_CONTRACTS.map((c) => (
            <Card key={c.dealId}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="font-semibold" style={{ color: "var(--forge-text)" }}>{c.dealName}</div>
                  <div className="text-xs mt-0.5" style={{ color: "var(--forge-text-dim)" }}>NFL MSA Ref: {c.nflMsaRef}</div>
                </div>
                <Badge variant={c.warningFlag ? "red" : "green"}>
                  {c.subcontractStatus}
                </Badge>
              </div>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>Revenue Share</div>
                  <div className="text-lg font-bold" style={{ color: "var(--forge-gold)" }}>{c.revenueSharePct}%</div>
                  <div className="text-xs" style={{ color: "var(--forge-text-dim)" }}>SEG receives on each invoice</div>
                </div>
                <div>
                  <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>GDA Go-Live Target</div>
                  <div className="font-medium" style={{ color: "var(--forge-text)" }}>
                    {c.gdaloliveDate ? formatDate(c.gdaloliveDate) : "Not set"}
                  </div>
                </div>
                <div>
                  <div className="text-xs mb-1" style={{ color: "var(--forge-text-dim)" }}>Warranty Risk</div>
                  {c.warningFlag ? (
                    <div>
                      <Badge variant="red">At risk</Badge>
                      <div className="text-xs mt-1" style={{ color: "#f87171" }}>
                        Agreement must be executed before go-live. Revenue share drops to 50% if GDA delayed.
                      </div>
                    </div>
                  ) : (
                    <Badge variant="green">Clear</Badge>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {tab === "invoices" && (
        <Card>
          <CardHeader><CardTitle>Invoices</CardTitle></CardHeader>
          {INVOICES.map((inv) => (
            <div key={inv.id} className="py-3 border-b last:border-0" style={{ borderColor: "var(--forge-border)" }}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-sm font-medium" style={{ color: "var(--forge-text)" }}>{inv.id}</div>
                  <div className="text-xs mt-0.5" style={{ color: "var(--forge-text-dim)" }}>
                    {inv.entity} · Due {formatDate(inv.dueDate)}
                  </div>
                </div>
                <Badge variant={inv.status === "Paid" ? "green" : inv.status === "Overdue" ? "red" : "gold"}>
                  {inv.status}
                </Badge>
              </div>
              <div className="mt-2 grid grid-cols-3 gap-4 text-xs">
                <div>
                  <span style={{ color: "var(--forge-text-dim)" }}>Gross: </span>
                  <span style={{ color: "var(--forge-text)" }}>{formatCurrency(inv.amount)}</span>
                </div>
                {inv.subcontractorShare && (
                  <div>
                    <span style={{ color: "var(--forge-text-dim)" }}>SEG share: </span>
                    <span style={{ color: "var(--forge-gold)" }}>{formatCurrency(inv.subcontractorShare)}</span>
                  </div>
                )}
                {inv.netSentraisAmount && (
                  <div>
                    <span style={{ color: "var(--forge-text-dim)" }}>Net Sentrais: </span>
                    <span style={{ color: "#4ade80" }}>{formatCurrency(inv.netSentraisAmount)}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}
