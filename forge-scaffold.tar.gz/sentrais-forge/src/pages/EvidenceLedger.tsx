import React, { useState } from "react";
import { Card, CardHeader, CardTitle } from "../components/ui/Card";
import { Badge } from "../components/ui/Badge";
import { sha256, formatDate } from "../lib/utils";
import type { EvidenceLedgerEntry } from "../types";

const SEED_ENTRIES: EvidenceLedgerEntry[] = [
  {
    id: "EL-001",
    hash: "a3f8c2d1e9b4...",
    timestamp: "2026-06-01T09:00:00Z",
    actor: "tye@sentrais.com",
    entityType: "milestone",
    entityId: "SEAR-2026",
    summary: "SEAR 2026 T-0 confirmed: June 11, 2026. All 11 city nodes active.",
    previousHash: "genesis",
  },
  {
    id: "EL-002",
    hash: "b7d4e1f2a8c5...",
    timestamp: "2026-06-03T14:22:00Z",
    actor: "tye@sentrais.com",
    entityType: "decision",
    entityId: "SEG-001",
    summary: "SEG subcontract term sheet signed. 70% revenue share structure confirmed. Agreement drafting in progress.",
    previousHash: "a3f8c2d1e9b4...",
  },
  {
    id: "EL-003",
    hash: "c2a9f3e6d1b8...",
    timestamp: "2026-06-07T10:45:00Z",
    actor: "tye@sentrais.com",
    entityType: "gate",
    entityId: "NFL-GDA-G2",
    summary: "NFL GDA Gate G2 passed. Blueprint360 POC validated. Hard block cleared.",
    previousHash: "b7d4e1f2a8c5...",
  },
];

const entityTypeColor: Record<string, string> = {
  milestone: "default",
  decision: "gold",
  gate: "green",
  engagement: "default",
  invoice: "dim",
  claim: "dim",
};

export function EvidenceLedger() {
  const [entries] = useState<EvidenceLedgerEntry[]>(SEED_ENTRIES);
  const [newSummary, setNewSummary] = useState("");
  const [newType, setNewType] = useState<EvidenceLedgerEntry["entityType"]>("milestone");
  const [generatedHash, setGeneratedHash] = useState<string | null>(null);

  async function handleGenerateHash() {
    if (!newSummary.trim()) return;
    const lastHash = entries[entries.length - 1]?.hash ?? "genesis";
    const input = `${lastHash}|${new Date().toISOString()}|tye@sentrais.com|${newSummary}`;
    const hash = await sha256(input);
    setGeneratedHash(hash);
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: "var(--forge-text)" }}>Evidence Ledger</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--forge-text-dim)" }}>
          SHA-256 cryptographic hash chain — immutable record of all decisions and milestones
        </p>
      </div>

      {/* New entry */}
      <Card>
        <CardHeader><CardTitle>Record New Entry</CardTitle></CardHeader>
        <div className="space-y-3">
          <select
            value={newType}
            onChange={(e) => setNewType(e.target.value as any)}
            className="w-full px-3 py-2 rounded text-sm"
            style={{ background: "var(--forge-navy-mid)", color: "var(--forge-text)", border: "1px solid var(--forge-border)" }}
          >
            {["milestone", "decision", "gate", "engagement", "invoice", "claim"].map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          <textarea
            value={newSummary}
            onChange={(e) => setNewSummary(e.target.value)}
            placeholder="Describe the decision, milestone, or event..."
            rows={3}
            className="w-full px-3 py-2 rounded text-sm resize-none"
            style={{ background: "var(--forge-navy-mid)", color: "var(--forge-text)", border: "1px solid var(--forge-border)" }}
          />
          <div className="flex items-center gap-3">
            <button
              onClick={handleGenerateHash}
              className="px-4 py-2 rounded text-sm font-medium transition-opacity hover:opacity-90"
              style={{ background: "var(--forge-accent)", color: "white" }}
            >
              Generate Hash
            </button>
            {generatedHash && (
              <div className="text-xs font-mono" style={{ color: "var(--forge-gold)" }}>
                {generatedHash.slice(0, 32)}...
              </div>
            )}
          </div>
          {generatedHash && (
            <div className="text-xs p-2 rounded" style={{ background: "var(--forge-navy-mid)", color: "var(--forge-text-dim)" }}>
              Copy this hash and record it in the Monday.com Evidence Ledger board and Firestore to complete the chain.
            </div>
          )}
        </div>
      </Card>

      {/* Chain */}
      <Card>
        <CardHeader><CardTitle>Ledger Chain ({entries.length} entries)</CardTitle></CardHeader>
        <div className="space-y-0">
          {[...entries].reverse().map((entry, i) => (
            <div key={entry.id} className="py-3 border-b last:border-0" style={{ borderColor: "var(--forge-border)" }}>
              <div className="flex items-start justify-between mb-1">
                <div className="flex items-center gap-2">
                  <Badge variant={entityTypeColor[entry.entityType] as any}>{entry.entityType}</Badge>
                  <span className="text-xs" style={{ color: "var(--forge-text-dim)" }}>{formatDate(entry.timestamp)}</span>
                </div>
                <span className="text-xs font-mono" style={{ color: "var(--forge-text-dim)" }}>{entry.hash}</span>
              </div>
              <div className="text-sm" style={{ color: "var(--forge-text)" }}>{entry.summary}</div>
              <div className="text-xs mt-1" style={{ color: "var(--forge-text-dim)" }}>
                {entry.actor} · prev: {entry.previousHash}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
