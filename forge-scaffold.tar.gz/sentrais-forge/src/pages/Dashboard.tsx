import React from "react";
import { Card, CardHeader, CardTitle } from "../components/ui/Card";
import { Badge } from "../components/ui/Badge";
import { formatCurrency } from "../lib/utils";

const entities = [
  { name: "Sentrais Corp", code: "CORP", phase: "D4 Deploy", deals: 3, revenue: 1200000 },
  { name: "SRI", code: "SRI", phase: "D3 Design", deals: 1, revenue: 0 },
  { name: "BGI / ARI", code: "BGI", phase: "D2 Diagnose", deals: 2, revenue: 85000 },
  { name: "Ventures", code: "VEN", phase: "D1 Discover", deals: 1, revenue: 0 },
];

const alerts = [
  { type: "red", label: "SEG subcontract not executed — NFL GDA at risk" },
  { type: "gold", label: "NC-G3 SIPE certification pending — 3 open items" },
  { type: "gold", label: "Claims Register: 4 slots unconfirmed" },
  { type: "dim", label: "Evidence Ledger: last entry 2 days ago" },
];

export function Dashboard() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-xl font-bold" style={{ color: "var(--forge-text)" }}>Command Center</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--forge-text-dim)" }}>
          Sentrais FORGE — GTM Playbook v1.0 · {new Date().toLocaleDateString("en-US", { dateStyle: "long" })}
        </p>
      </div>

      {/* Entity status strip */}
      <div className="grid grid-cols-4 gap-4">
        {entities.map((e) => (
          <Card key={e.code}>
            <div className="text-xs font-bold tracking-wider mb-2" style={{ color: "var(--forge-gold)" }}>{e.code}</div>
            <div className="text-sm font-medium mb-1" style={{ color: "var(--forge-text)" }}>{e.name}</div>
            <Badge variant="default" className="mb-2">{e.phase}</Badge>
            <div className="mt-2 text-xs space-y-0.5" style={{ color: "var(--forge-text-dim)" }}>
              <div>{e.deals} active deal{e.deals !== 1 ? "s" : ""}</div>
              {e.revenue > 0 && <div>{formatCurrency(e.revenue)} pipeline</div>}
            </div>
          </Card>
        ))}
      </div>

      {/* Alerts */}
      <Card>
        <CardHeader>
          <CardTitle>Active Alerts</CardTitle>
        </CardHeader>
        <div className="space-y-2">
          {alerts.map((a, i) => (
            <div key={i} className="flex items-center gap-3 text-sm py-1.5 border-b last:border-0" style={{ borderColor: "var(--forge-border)" }}>
              <Badge variant={a.type as any}>{a.type === "red" ? "URGENT" : a.type === "gold" ? "WARN" : "INFO"}</Badge>
              <span style={{ color: "var(--forge-text)" }}>{a.label}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* NIN Phase summary */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle>NIN Delivery Pipeline</CardTitle></CardHeader>
          {["D1 Discover", "D2 Diagnose", "D3 Design", "D4 Deploy", "D5 Debrief"].map((phase, i) => (
            <div key={phase} className="flex items-center justify-between py-1.5 text-sm border-b last:border-0" style={{ borderColor: "var(--forge-border)" }}>
              <span style={{ color: i === 3 ? "var(--forge-text)" : "var(--forge-text-dim)" }}>{phase}</span>
              <Badge variant={i === 3 ? "green" : "dim"}>{i === 3 ? "3 active" : i < 3 ? "complete" : "—"}</Badge>
            </div>
          ))}
        </Card>

        <Card>
          <CardHeader><CardTitle>Doctrine Mode</CardTitle></CardHeader>
          <div className="flex items-center gap-3 py-3">
            <Badge variant="green" className="text-sm px-3 py-1">Steady State</Badge>
            <span className="text-xs" style={{ color: "var(--forge-text-dim)" }}>No active surge or incident flags</span>
          </div>
          <div className="text-xs mt-2 space-y-1" style={{ color: "var(--forge-text-dim)" }}>
            <div>SEAR 2026 T-0: June 11, 2026</div>
            <div>NFL GDA Go-Live: TBD (SEG pending)</div>
          </div>
        </Card>
      </div>
    </div>
  );
}
