import React, { useState } from "react";
import { auth, googleProvider } from "../lib/firebase";
import { signInWithPopup } from "firebase/auth";

export function Login() {
  const [error, setError] = useState<string | null>(null);

  async function handleGoogleSignIn() {
    try {
      setError(null);
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      setError(err.message ?? "Sign in failed");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: "var(--forge-navy)" }}>
      <div className="w-80 space-y-6">
        <div className="text-center">
          <div className="text-xs font-bold tracking-widest uppercase mb-2" style={{ color: "var(--forge-gold)" }}>FORGE</div>
          <h1 className="text-2xl font-bold" style={{ color: "var(--forge-text)" }}>Command Center</h1>
          <p className="text-sm mt-1" style={{ color: "var(--forge-text-dim)" }}>Sentrais proprietary delivery OS</p>
        </div>

        <div className="rounded-lg p-6 space-y-4" style={{ background: "var(--forge-surface)", border: "1px solid var(--forge-border)" }}>
          <button
            onClick={handleGoogleSignIn}
            className="w-full flex items-center justify-center gap-3 px-4 py-2.5 rounded text-sm font-medium transition-opacity hover:opacity-90"
            style={{ background: "var(--forge-accent)", color: "white" }}
          >
            Sign in with Google Workspace
          </button>
          <p className="text-xs text-center" style={{ color: "var(--forge-text-dim)" }}>
            sentrais.com accounts only
          </p>
          {error && (
            <p className="text-xs text-center" style={{ color: "#f87171" }}>{error}</p>
          )}
        </div>
      </div>
    </div>
  );
}
